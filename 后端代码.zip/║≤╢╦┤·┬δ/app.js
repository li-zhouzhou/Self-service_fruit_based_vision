const express = require('express')
const apiR = require('./router/api')
//const cors = require('cors')
const app = express()

//app.use(cors())
app.use(express.urlencoded({ extended: false }))
app.use((req, res, next) => {
  res.cc = (err, status = 400) => {
    res.send({
      status,
      message: err instanceof Error ? err.message : err,
    })
  }
  next()
})

app.use('/api', apiR)
//app.use(express.static('./static'))


app.listen(2022, () => {
  console.log('服务已启动\n')
})
