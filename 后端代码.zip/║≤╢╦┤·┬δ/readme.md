## 电赛后台api接口


徐寅哲


----

### api



- get `/api/test` 测试get接口
- post `api/test` 测试post接口
- get `/api/info` 获取订单信息
- post `/api/info` 提交订单信息