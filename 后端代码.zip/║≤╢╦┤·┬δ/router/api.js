const express = require('express')
const router = express.Router()
const func = require('./func')

router.post('/info', func.setinfo)
router.get('/info', func.getinfo)
router.get('/test', func.getTest)
router.post('/test', func.postTest)
router.post('/paid',func.paid)

module.exports = router
