const mysql = require('mysql')

const db = mysql.createPool({
  host: '127.0.0.1',
  user: 'fruits_db',
  password: 'xyz12345',
  database: 'fruits_db',
})

exports.setinfo = (req, res) => {
  const { type, weight } = req.body
  console.log(type, weight)
  const sql = 'insert into twinfo set ?'
  db.query(sql, { type, weight }, (err, result) => {
    if (err) return res.cc(err)
    if (result.affectedRows !== 1) return res.cc('发送失败,请重试')
    res.cc('请求成功', 200)
  })
}

exports.getinfo = (req, res) => {
  const sql =
    'select id,type,weight From twinfo where id in (SELECT max(id) from twinfo WHERE status!=1 )'
  db.query(sql, (err, result) => {
    if (err) return res.cc(err)
    res.send({
      status: 200,
      data: result[0],
    })
  })
}

exports.paid = (req,res)=>{
  console.log(req.body);
  const {id,token} = req.body
  if(!id || !token) return res.cc("wrong require")
  if(token!=="brgzz") return res.cc('wrong token')
  const sql = `update twinfo set status=1 where id=${id}`
  db.query(sql,(err,result)=>{
    if (err) return res.cc(err)
    if (result.affectedRows !== 1) return res.cc('发送失败,请重试')
    res.cc("paid successfully",200)
  })
}

exports.getTest = (req, res) => {
  console.log('require of get');
  console.log(req.query);
  res.send({
    status: 200,
    msg: 'get请求成功',
    data: req.query,
  })
}
exports.postTest = (req, res) => {
  console.log('require of post');
  console.log(req.body);
  res.send({
    status: 200,
    msg: 'post请求成功',
    data: req.body,
  })
}
